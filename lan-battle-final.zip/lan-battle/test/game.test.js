import assert from "node:assert/strict";
import test from "node:test";
import { GROUND_Y, PLAYER_RADIUS } from "../src/config.js";
import { GameSession } from "../src/game.js";

function createGame(mode = "pve", playerCount = 1, classes = []) {
  const emitted = [];
  const io = {
    to(target) {
      return {
        emit(event, payload) {
          emitted.push({ target, event, payload });
        },
      };
    },
  };
  const players = new Map();
  for (let index = 0; index < playerCount; index += 1) {
    players.set(`player-${index}`, {
      id: `player-${index}`,
      name: `玩家${index + 1}`,
      classId: classes[index] ?? "assault",
      color: "#fff",
    });
  }
  const room = { code: "TEST1", mode, players };
  return { game: new GameSession(room, io, () => {}), emitted };
}

test("服务端根据输入权威更新移动状态", () => {
  const { game } = createGame();
  const player = game.players.get("player-0");
  const startX = player.x;
  game.setInput(player.id, { right: true, jump: true });
  game.updatePlayers(1 / 30);

  assert.ok(player.x > startX);
  assert.ok(player.y < GROUND_Y - PLAYER_RADIUS);
  assert.equal(player.facing, 1);
});

test("经验升级会向对应玩家发出三选一", () => {
  const { game, emitted } = createGame();
  const player = game.players.get("player-0");
  game.addExperience(player, player.xpNeeded);

  assert.equal(player.level, 2);
  assert.equal(player.pendingUpgrade.length, 3);
  assert.ok(emitted.some((item) => item.target === player.id && item.event === "upgrade:choices"));
});

test("职业属性和主动技能由服务端计算", () => {
  const { game } = createGame("pve", 2, ["guardian", "medic"]);
  const guardian = game.players.get("player-0");
  const medic = game.players.get("player-1");

  assert.equal(guardian.className, "守卫");
  assert.ok(guardian.maxHp > medic.maxHp);

  game.setInput(guardian.id, { skill: true });
  game.updatePlayers(1 / 30);
  assert.ok(guardian.shield > 0);
  assert.ok(guardian.skillCooldown > 0);
});

test("商店会消耗金币并应用强化", () => {
  const { game } = createGame();
  const player = game.players.get("player-0");
  player.gold = 20;
  const before = player.damage;

  assert.equal(game.buyShopItem(player.id, "damage"), true);
  assert.equal(player.gold, 6);
  assert.ok(player.damage > before);
});

test("Boss 死亡会掉落宝箱和金币", () => {
  const { game } = createGame();
  const player = game.players.get("player-0");
  const boss = {
    id: "boss",
    x: player.x + 40,
    y: player.y,
    radius: 58,
    hp: 1,
    maxHp: 1,
    elite: true,
    boss: true,
  };
  game.enemies.set(boss.id, boss);
  const hit = game.hitEnemy({
    ownerId: player.id,
    x: boss.x,
    y: boss.y,
    radius: 6,
    damage: 10,
    pierce: 0,
  });

  assert.equal(hit, true);
  assert.ok([...game.pickups.values()].some((pickup) => pickup.type === "chest"));
  assert.ok([...game.pickups.values()].some((pickup) => pickup.type === "gold"));
});

test("PvP 在只剩一人时结束并宣布胜者", () => {
  const { game } = createGame("pvp", 2);
  game.elapsed = 3;
  game.players.get("player-1").alive = false;
  game.players.get("player-1").hp = 0;
  game.checkEndConditions();

  assert.equal(game.ended, true);
  assert.deepEqual(game.result.winnerIds, ["player-0"]);
});

test("PvE 怪物死亡会生成经验掉落", () => {
  const { game } = createGame();
  const player = game.players.get("player-0");
  const enemy = {
    id: "enemy",
    x: player.x + 40,
    y: player.y,
    radius: 22,
    hp: 1,
    maxHp: 1,
    elite: false,
  };
  game.enemies.set(enemy.id, enemy);
  const hit = game.hitEnemy({
    ownerId: player.id,
    x: enemy.x,
    y: enemy.y,
    radius: 6,
    damage: 10,
  });

  assert.equal(hit, true);
  assert.equal(game.enemies.size, 0);
  assert.ok([...game.pickups.values()].some((pickup) => pickup.type === "xp"));
  assert.ok([...game.pickups.values()].some((pickup) => pickup.type === "gold"));
  assert.equal(player.kills, 1);
});

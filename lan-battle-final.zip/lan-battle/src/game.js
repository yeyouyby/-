import {
  GROUND_Y,
  MAP_HEIGHT,
  MAP_WIDTH,
  PLAYER_BASE,
  getPlayerClass,
  PLAYER_RADIUS,
  SERVER_TICK_RATE,
  SNAPSHOT_RATE,
  SHOP_ITEMS,
  UPGRADE_POOL,
} from "./config.js";
import { clamp, distanceSquared, randomId, sample } from "./utils.js";

const GRAVITY = 1800;
const GAME_DURATION = 150;
const WAVE_DURATION = 30;
const MAX_WAVES = 5;
const SHOP_OPTIONS = SHOP_ITEMS.map(({ id, name, description, cost }) => ({ id, name, description, cost }));
const PLATFORMS = [
  { x: 420, y: 500, width: 320, height: 24 },
  { x: 1120, y: 430, width: 360, height: 24 },
  { x: 1810, y: 510, width: 330, height: 24 },
  { x: 2500, y: 410, width: 300, height: 24 },
];

export class GameSession {
  constructor(room, io, onFinished, options = {}) {
    this.room = room;
    this.io = io;
    this.onFinished = onFinished;
    this.tickRate = options.tickRate ?? SERVER_TICK_RATE;
    this.snapshotEvery = Math.max(1, Math.round(this.tickRate / SNAPSHOT_RATE));
    this.now = options.now ?? (() => Date.now());
    this.players = new Map();
    this.enemies = new Map();
    this.projectiles = new Map();
    this.pickups = new Map();
    this.elapsed = 0;
    this.wave = 1;
    this.waveSpawnBudget = 0;
    this.spawnCooldown = 0;
    this.bossWavesSpawned = new Set();
    this.tickNumber = 0;
    this.ended = false;
    this.result = null;
    this.loop = null;
    this.buildPlayers();
  }

  buildPlayers() {
    const count = this.room.players.size;
    let index = 0;
    for (const lobbyPlayer of this.room.players.values()) {
      const playerClass = getPlayerClass(lobbyPlayer.classId);
      const stats = { ...PLAYER_BASE, ...playerClass.stats };
      const spread = count === 1 ? MAP_WIDTH / 2 : 300 + (index * (MAP_WIDTH - 600)) / (count - 1);
      this.players.set(lobbyPlayer.id, {
        id: lobbyPlayer.id,
        name: lobbyPlayer.name,
        classId: playerClass.id,
        className: playerClass.name,
        skillName: playerClass.skillName,
        color: lobbyPlayer.color,
        x: spread,
        y: GROUND_Y - PLAYER_RADIUS,
        vx: 0,
        vy: 0,
        facing: index % 2 === 0 ? 1 : -1,
        grounded: true,
        hp: stats.maxHp,
        maxHp: stats.maxHp,
        speed: stats.speed,
        jumpSpeed: stats.jumpSpeed,
        damage: stats.damage,
        attackRate: stats.attackRate,
        projectileSpeed: stats.projectileSpeed,
        armor: stats.armor,
        regen: stats.regen,
        critChance: stats.critChance,
        pierce: stats.pierce,
        projectileCount: 1,
        pickupRange: stats.pickupRange,
        attackCooldown: Math.random() * 0.4,
        skillCooldown: 0,
        skillCooldownMax: playerClass.skillCooldown,
        skillPressed: false,
        shield: 0,
        shieldFor: 0,
        invulnerableFor: 1.5,
        alive: true,
        downFor: 0,
        kills: 0,
        gold: 0,
        level: 1,
        xp: 0,
        xpNeeded: 25,
        pendingUpgrade: null,
        upgradeDeadline: 0,
        input: { left: false, right: false, jump: false, skill: false },
      });
      index += 1;
    }
  }

  start() {
    if (this.loop || this.ended) return;
    this.io.to(this.room.code).emit("game:start", {
      mode: this.room.mode,
      shop: SHOP_OPTIONS,
      map: { width: MAP_WIDTH, height: MAP_HEIGHT, groundY: GROUND_Y, platforms: PLATFORMS },
    });
    const dt = 1 / this.tickRate;
    this.loop = setInterval(() => this.update(dt), 1000 / this.tickRate);
  }

  stop() {
    if (this.loop) clearInterval(this.loop);
    this.loop = null;
  }

  removePlayer(playerId) {
    this.players.delete(playerId);
    if (!this.ended) this.checkEndConditions();
  }

  setInput(playerId, rawInput = {}) {
    const player = this.players.get(playerId);
    if (!player) return;
    player.input = {
      left: Boolean(rawInput.left),
      right: Boolean(rawInput.right),
      jump: Boolean(rawInput.jump),
      skill: Boolean(rawInput.skill),
    };
  }

  chooseUpgrade(playerId, upgradeId) {
    const player = this.players.get(playerId);
    if (!player?.pendingUpgrade) return false;
    const upgrade = player.pendingUpgrade.find((candidate) => candidate.id === upgradeId);
    if (!upgrade) return false;
    UPGRADE_POOL.find((candidate) => candidate.id === upgrade.id)?.apply(player);
    player.pendingUpgrade = null;
    player.upgradeDeadline = 0;
    this.io.to(playerId).emit("upgrade:applied", { id: upgrade.id });
    return true;
  }

  buyShopItem(playerId, itemId) {
    const player = this.players.get(playerId);
    const item = SHOP_ITEMS.find((candidate) => candidate.id === itemId);
    if (!player || !item || !player.alive) return false;
    if (player.gold < item.cost) {
      this.io.to(playerId).emit("shop:error", { message: "金币不足" });
      return false;
    }
    player.gold -= item.cost;
    item.apply(player);
    this.io.to(playerId).emit("shop:bought", { id: item.id, gold: player.gold });
    return true;
  }

  update(dt) {
    if (this.ended) return;
    this.elapsed += dt;
    this.tickNumber += 1;
    this.updatePlayers(dt);
    if (this.room.mode === "pve") this.updatePve(dt);
    this.updateProjectiles(dt);
    this.updatePickups(dt);
    this.resolvePendingUpgrades();
    this.checkEndConditions();
    if (this.tickNumber % this.snapshotEvery === 0) this.broadcastSnapshot();
  }

  updatePlayers(dt) {
    for (const player of this.players.values()) {
      if (!player.alive) {
        if (this.room.mode === "pve" && this.livingPlayers().length > 0) {
          player.downFor -= dt;
          if (player.downFor <= 0) this.revivePlayer(player);
        }
        player.skillPressed = Boolean(player.input.skill);
        continue;
      }
      player.invulnerableFor = Math.max(0, player.invulnerableFor - dt);
      player.skillCooldown = Math.max(0, player.skillCooldown - dt);
      player.shieldFor = Math.max(0, player.shieldFor - dt);
      if (player.shieldFor <= 0) player.shield = 0;
      if (player.regen > 0) player.hp = Math.min(player.maxHp, player.hp + player.regen * dt);
      if (player.input.skill && !player.skillPressed && player.skillCooldown <= 0) this.useSkill(player);
      player.skillPressed = Boolean(player.input.skill);
      const direction = Number(player.input.right) - Number(player.input.left);
      player.vx = direction * player.speed;
      if (direction !== 0) player.facing = direction;
      if (player.input.jump && player.grounded) {
        player.vy = -player.jumpSpeed;
        player.grounded = false;
      }

      const previousBottom = player.y + PLAYER_RADIUS;
      player.vy += GRAVITY * dt;
      player.x = clamp(player.x + player.vx * dt, PLAYER_RADIUS, MAP_WIDTH - PLAYER_RADIUS);
      player.y += player.vy * dt;
      player.grounded = false;

      let landingY = GROUND_Y;
      for (const platform of PLATFORMS) {
        const withinX = player.x + PLAYER_RADIUS > platform.x && player.x - PLAYER_RADIUS < platform.x + platform.width;
        const crossedTop = previousBottom <= platform.y && player.y + PLAYER_RADIUS >= platform.y;
        if (withinX && crossedTop && player.vy >= 0) landingY = Math.min(landingY, platform.y);
      }
      if (player.y + PLAYER_RADIUS >= landingY) {
        player.y = landingY - PLAYER_RADIUS;
        player.vy = 0;
        player.grounded = true;
      }

      player.attackCooldown -= dt;
      if (player.attackCooldown <= 0) {
        const target = this.findTarget(player);
        if (target) this.fireAt(player, target);
        player.attackCooldown = 1 / player.attackRate;
      }
    }
  }

  useSkill(player) {
    switch (player.classId) {
      case "assault":
        this.fireBurst(player);
        break;
      case "guardian":
        player.shield = Math.min(85, player.shield + 55);
        player.shieldFor = 5;
        player.invulnerableFor = Math.max(player.invulnerableFor, 0.35);
        break;
      case "medic":
        this.healPulse(player);
        break;
      case "scout":
        player.x = clamp(player.x + player.facing * 320, PLAYER_RADIUS, MAP_WIDTH - PLAYER_RADIUS);
        player.invulnerableFor = Math.max(player.invulnerableFor, 0.32);
        break;
      default:
        this.fireBurst(player);
        break;
    }
    player.skillCooldown = player.skillCooldownMax;
    this.io.to(this.room.code).emit("game:event", { type: "skill", playerId: player.id, skillName: player.skillName });
  }

  fireBurst(player) {
    const target = this.findTarget(player);
    const baseAngle = target ? Math.atan2(target.y - player.y, target.x - player.x) : (player.facing > 0 ? 0 : Math.PI);
    for (let index = 0; index < 8; index += 1) {
      const spread = (index - 3.5) * 0.105;
      const angle = baseAngle + spread;
      const id = randomId("burst");
      this.projectiles.set(id, {
        id,
        ownerId: player.id,
        x: player.x + Math.cos(angle) * (PLAYER_RADIUS + 8),
        y: player.y + Math.sin(angle) * (PLAYER_RADIUS + 8),
        vx: Math.cos(angle) * player.projectileSpeed * 1.12,
        vy: Math.sin(angle) * player.projectileSpeed * 1.12,
        radius: 5,
        damage: player.damage * 0.72,
        pierce: Math.max(0, player.pierce - 1),
        life: 1,
      });
    }
  }

  healPulse(player) {
    for (const target of this.players.values()) {
      if (distanceSquared(player, target) > 460 * 460) continue;
      if (!target.alive && this.room.mode === "pve") {
        target.alive = true;
        target.downFor = 0;
        target.invulnerableFor = 1.6;
      }
      if (target.alive) target.hp = Math.min(target.maxHp, target.hp + 38);
    }
  }

  updatePve(dt) {
    const targetWave = Math.min(MAX_WAVES, Math.floor(this.elapsed / WAVE_DURATION) + 1);
    if (targetWave !== this.wave) {
      this.wave = targetWave;
      for (const player of this.livingPlayers()) {
        player.hp = Math.min(player.maxHp, player.hp + player.maxHp * 0.25);
      }
      if ((this.wave === 3 || this.wave === 5) && !this.bossWavesSpawned.has(this.wave)) {
        this.spawnEnemy("boss");
        this.bossWavesSpawned.add(this.wave);
      }
      this.io.to(this.room.code).emit("game:event", { type: "wave", wave: this.wave });
    }

    this.waveSpawnBudget += dt * (0.8 + this.wave * 0.42);
    this.spawnCooldown -= dt;
    const maxEnemies = 7 + this.wave * 5;
    if (this.waveSpawnBudget >= 1 && this.spawnCooldown <= 0 && this.enemies.size < maxEnemies) {
      this.spawnEnemy();
      this.waveSpawnBudget -= 1;
      this.spawnCooldown = Math.max(0.16, 0.52 - this.wave * 0.05);
    }

    for (const enemy of this.enemies.values()) {
      const target = this.closestLivingPlayer(enemy);
      if (!target) continue;
      const direction = Math.sign(target.x - enemy.x);
      enemy.vx = direction * enemy.speed;
      enemy.x = clamp(enemy.x + enemy.vx * dt, enemy.radius, MAP_WIDTH - enemy.radius);
      enemy.y = GROUND_Y - enemy.radius + Math.sin(this.elapsed * enemy.bobSpeed) * enemy.bobHeight;
      enemy.attackCooldown -= dt;
      const hitRange = enemy.radius + PLAYER_RADIUS + 8;
      if (distanceSquared(enemy, target) <= hitRange * hitRange && enemy.attackCooldown <= 0) {
        this.damagePlayer(target, enemy.damage);
        enemy.attackCooldown = 0.75;
      }
    }
  }

  spawnEnemy(kind = "grunt") {
    const livingPlayers = this.livingPlayers();
    if (livingPlayers.length === 0) return;
    const anchor = livingPlayers[Math.floor(Math.random() * livingPlayers.length)];
    const side = Math.random() < 0.5 ? -1 : 1;
    const x = clamp(anchor.x + side * (650 + Math.random() * 400), 40, MAP_WIDTH - 40);
    const boss = kind === "boss";
    const elite = boss || kind === "elite" || Math.random() < 0.05 * this.wave;
    const radius = boss ? 58 : elite ? 32 : 22;
    const hp = (boss ? 700 + this.players.size * 180 : elite ? 120 : 42) * (1 + (this.wave - 1) * 0.33);
    const enemy = {
      id: randomId("enemy"),
      x,
      y: GROUND_Y - radius,
      vx: 0,
      radius,
      hp,
      maxHp: hp,
      speed: (boss ? 82 : elite ? 105 : 145) + this.wave * 7,
      damage: (boss ? 32 : elite ? 22 : 12) + this.wave * 2,
      attackCooldown: Math.random() * 0.5,
      elite,
      boss,
      bobSpeed: boss ? 2.3 : 0,
      bobHeight: boss ? 7 : 0,
    };
    this.enemies.set(enemy.id, enemy);
  }

  findTarget(player) {
    const candidates = this.room.mode === "pve"
      ? [...this.enemies.values()]
      : this.livingPlayers().filter((candidate) => candidate.id !== player.id);
    let closest = null;
    let closestDistance = 780 * 780;
    for (const candidate of candidates) {
      const candidateDistance = distanceSquared(player, candidate);
      if (candidateDistance < closestDistance) {
        closest = candidate;
        closestDistance = candidateDistance;
      }
    }
    return closest;
  }

  fireAt(player, target) {
    const baseAngle = Math.atan2(target.y - player.y, target.x - player.x);
    const count = player.projectileCount;
    for (let index = 0; index < count; index += 1) {
      const spread = (index - (count - 1) / 2) * 0.12;
      const angle = baseAngle + spread;
      const projectile = {
        id: randomId("shot"),
        ownerId: player.id,
        x: player.x + Math.cos(angle) * (PLAYER_RADIUS + 8),
        y: player.y + Math.sin(angle) * (PLAYER_RADIUS + 8),
        vx: Math.cos(angle) * player.projectileSpeed,
        vy: Math.sin(angle) * player.projectileSpeed,
        radius: 6,
        damage: player.damage * (Math.random() < player.critChance ? 2 : 1),
        pierce: player.pierce,
        life: 1.25,
      };
      this.projectiles.set(projectile.id, projectile);
    }
  }

  updateProjectiles(dt) {
    for (const projectile of this.projectiles.values()) {
      projectile.x += projectile.vx * dt;
      projectile.y += projectile.vy * dt;
      projectile.life -= dt;
      if (
        projectile.life <= 0 ||
        projectile.x < 0 ||
        projectile.x > MAP_WIDTH ||
        projectile.y < 0 ||
        projectile.y > MAP_HEIGHT
      ) {
        this.projectiles.delete(projectile.id);
        continue;
      }
      const hit = this.room.mode === "pve"
        ? this.hitEnemy(projectile)
        : this.hitOpponent(projectile);
      if (hit) this.projectiles.delete(projectile.id);
    }
  }

  hitEnemy(projectile) {
    for (const enemy of this.enemies.values()) {
      const hitRadius = enemy.radius + projectile.radius;
      if (distanceSquared(projectile, enemy) > hitRadius * hitRadius) continue;
      enemy.hp -= projectile.damage;
      if (enemy.hp <= 0) {
        this.enemies.delete(enemy.id);
        const owner = this.players.get(projectile.ownerId);
        this.defeatEnemy(enemy, owner);
      }
      if (projectile.pierce > 0) {
        projectile.pierce -= 1;
        return false;
      }
      return true;
    }
    return false;
  }

  defeatEnemy(enemy, owner) {
    if (owner) owner.kills += 1;
    const xpValue = enemy.boss ? 55 : enemy.elite ? 18 : 7;
    const goldValue = enemy.boss ? 32 : enemy.elite ? 9 : 3;
    this.spawnPickup(enemy, xpValue, "xp");
    this.spawnPickup({ ...enemy, x: enemy.x + 18, y: enemy.y - 6 }, goldValue, "gold");
    if (enemy.elite && Math.random() < 0.24) this.spawnPickup({ ...enemy, x: enemy.x - 18 }, 10, "chest");
    if (enemy.boss) {
      this.spawnPickup({ ...enemy, x: enemy.x - 45 }, 20, "chest");
      this.spawnPickup({ ...enemy, x: enemy.x + 45 }, 20, "chest");
      this.io.to(this.room.code).emit("game:event", { type: "bossDefeated" });
    }
  }

  hitOpponent(projectile) {
    for (const player of this.livingPlayers()) {
      if (player.id === projectile.ownerId || player.invulnerableFor > 0) continue;
      const hitRadius = PLAYER_RADIUS + projectile.radius;
      if (distanceSquared(projectile, player) > hitRadius * hitRadius) continue;
      this.damagePlayer(player, projectile.damage);
      if (!player.alive) {
        const owner = this.players.get(projectile.ownerId);
        if (owner) owner.kills += 1;
      }
      if (projectile.pierce > 0) {
        projectile.pierce -= 1;
        return false;
      }
      return true;
    }
    return false;
  }

  damagePlayer(player, damage) {
    if (!player.alive || player.invulnerableFor > 0) return;
    let remainingDamage = Math.max(1, damage - player.armor);
    if (player.shield > 0) {
      const absorbed = Math.min(player.shield, remainingDamage);
      player.shield -= absorbed;
      remainingDamage -= absorbed;
    }
    player.hp = Math.max(0, player.hp - remainingDamage);
    player.invulnerableFor = 0.16;
    if (player.hp <= 0) {
      player.alive = false;
      player.downFor = 8;
      player.vx = 0;
      player.vy = 0;
    }
  }

  revivePlayer(player) {
    player.alive = true;
    player.hp = Math.max(30, player.maxHp * 0.4);
    player.x = MAP_WIDTH / 2 + (Math.random() - 0.5) * 200;
    player.y = GROUND_Y - PLAYER_RADIUS;
    player.invulnerableFor = 2;
  }

  spawnPickup(enemy, value, type = "xp") {
    const pickup = {
      id: randomId(type),
      type,
      x: enemy.x,
      y: enemy.y,
      value,
      life: type === "chest" ? 35 : 20,
    };
    this.pickups.set(pickup.id, pickup);
  }

  updatePickups(dt) {
    for (const pickup of this.pickups.values()) {
      pickup.life -= dt;
      if (pickup.life <= 0) {
        this.pickups.delete(pickup.id);
        continue;
      }
      let collector = null;
      let closestDistance = Number.POSITIVE_INFINITY;
      for (const player of this.livingPlayers()) {
        const pickupDistance = distanceSquared(pickup, player);
        if (pickupDistance < player.pickupRange ** 2 && pickupDistance < closestDistance) {
          collector = player;
          closestDistance = pickupDistance;
        }
      }
      if (!collector) continue;
      const distance = Math.sqrt(closestDistance);
      if (distance < PLAYER_RADIUS + 12) {
        this.collectPickup(collector, pickup);
        this.pickups.delete(pickup.id);
        continue;
      }
      const pull = Math.min(1, dt * 9);
      pickup.x += (collector.x - pickup.x) * pull;
      pickup.y += (collector.y - pickup.y) * pull;
    }
  }

  collectPickup(player, pickup) {
    if (pickup.type === "gold") {
      player.gold += pickup.value;
      return;
    }
    if (pickup.type === "chest") {
      player.gold += pickup.value;
      if (!player.pendingUpgrade) this.offerUpgrade(player);
      this.io.to(player.id).emit("game:event", { type: "chest", gold: pickup.value });
      return;
    }
    this.addExperience(player, pickup.value);
  }

  addExperience(player, amount) {
    player.xp += amount;
    while (player.xp >= player.xpNeeded) {
      player.xp -= player.xpNeeded;
      player.level += 1;
      player.xpNeeded = Math.round(player.xpNeeded * 1.32);
      if (!player.pendingUpgrade) this.offerUpgrade(player);
    }
  }

  offerUpgrade(player) {
    const choices = sample(UPGRADE_POOL, 3).map(({ id, name, description }) => ({ id, name, description }));
    player.pendingUpgrade = choices;
    player.upgradeDeadline = this.now() + 10_000;
    this.io.to(player.id).emit("upgrade:choices", choices);
  }

  resolvePendingUpgrades() {
    const now = this.now();
    for (const player of this.players.values()) {
      if (player.pendingUpgrade && now >= player.upgradeDeadline) {
        this.chooseUpgrade(player.id, player.pendingUpgrade[0].id);
      }
    }
  }

  livingPlayers() {
    return [...this.players.values()].filter((player) => player.alive);
  }

  closestLivingPlayer(point) {
    let closest = null;
    let closestDistance = Number.POSITIVE_INFINITY;
    for (const player of this.livingPlayers()) {
      const playerDistance = distanceSquared(point, player);
      if (playerDistance < closestDistance) {
        closest = player;
        closestDistance = playerDistance;
      }
    }
    return closest;
  }

  checkEndConditions() {
    if (this.ended) return;
    const living = this.livingPlayers();
    if (this.players.size === 0) {
      this.finish({ title: "房间已关闭", winnerIds: [] });
      return;
    }
    if (this.room.mode === "pvp") {
      if (living.length <= 1 && this.elapsed > 2) {
        this.finish({
          title: living[0] ? `${living[0].name} 获胜` : "无人幸存",
          winnerIds: living.map((player) => player.id),
        });
      } else if (this.elapsed >= GAME_DURATION) {
        const highest = [...this.players.values()].sort((a, b) => b.kills - a.kills || b.hp - a.hp)[0];
        this.finish({ title: `${highest.name} 获胜`, winnerIds: [highest.id] });
      }
      return;
    }
    if (living.length === 0) {
      this.finish({ title: `挑战失败，坚持了 ${Math.floor(this.elapsed)} 秒`, winnerIds: [] });
    } else if (this.elapsed >= WAVE_DURATION * MAX_WAVES) {
      this.finish({ title: "合作胜利，所有波次已清除", winnerIds: living.map((player) => player.id) });
    }
  }

  finish(result) {
    this.ended = true;
    this.result = result;
    this.stop();
    this.broadcastSnapshot();
    this.io.to(this.room.code).emit("game:end", result);
  }

  broadcastSnapshot() {
    this.io.to(this.room.code).emit("game:snapshot", this.snapshot());
  }

  snapshot() {
    return {
      elapsed: this.elapsed,
      duration: this.room.mode === "pve" ? WAVE_DURATION * MAX_WAVES : GAME_DURATION,
      wave: this.wave,
      ended: this.ended,
      result: this.result,
      players: [...this.players.values()].map((player) => ({
        id: player.id,
        name: player.name,
        classId: player.classId,
        className: player.className,
        skillName: player.skillName,
        color: player.color,
        x: player.x,
        y: player.y,
        vx: player.vx,
        vy: player.vy,
        facing: player.facing,
        hp: player.hp,
        maxHp: player.maxHp,
        shield: player.shield,
        armor: player.armor,
        skillCooldown: player.skillCooldown,
        skillCooldownMax: player.skillCooldownMax,
        alive: player.alive,
        downFor: Math.max(0, player.downFor),
        kills: player.kills,
        gold: player.gold,
        level: player.level,
        xp: player.xp,
        xpNeeded: player.xpNeeded,
      })),
      enemies: [...this.enemies.values()],
      projectiles: [...this.projectiles.values()],
      pickups: [...this.pickups.values()],
    };
  }
}

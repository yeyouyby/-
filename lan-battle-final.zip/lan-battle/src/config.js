export const SERVER_TICK_RATE = 30;
export const SNAPSHOT_RATE = 15;
export const MAP_WIDTH = 3200;
export const MAP_HEIGHT = 720;
export const GROUND_Y = 620;
export const PLAYER_RADIUS = 24;
export const MAX_PLAYERS = 8;
export const ROOM_CODE_LENGTH = 5;

export const PLAYER_BASE = {
  maxHp: 100,
  speed: 310,
  jumpSpeed: 650,
  damage: 18,
  attackRate: 1.6,
  projectileSpeed: 760,
  pickupRange: 120,
  armor: 0,
  regen: 0,
  critChance: 0.05,
  pierce: 0,
};

export const PLAYER_CLASSES = [
  {
    id: "assault",
    name: "突击手",
    description: "均衡火力，主动技能会向前方倾泻弹幕。",
    skillName: "弹幕爆发",
    skillDescription: "E：朝最近目标或面朝方向连射 8 发弹丸。",
    skillCooldown: 7,
    stats: {
      maxHp: 105,
      speed: 315,
      damage: 20,
      attackRate: 1.75,
      armor: 1,
      critChance: 0.08,
    },
  },
  {
    id: "guardian",
    name: "守卫",
    description: "高生命和护甲，能展开临时护盾顶住怪潮。",
    skillName: "能量护盾",
    skillDescription: "E：获得 55 护盾并短暂无敌。",
    skillCooldown: 12,
    stats: {
      maxHp: 145,
      speed: 260,
      damage: 16,
      attackRate: 1.35,
      armor: 5,
    },
  },
  {
    id: "medic",
    name: "医师",
    description: "伤害较低，可治疗附近队友并扶起倒地队友。",
    skillName: "急救脉冲",
    skillDescription: "E：治疗 460 范围内队友，合作模式可扶起倒地者。",
    skillCooldown: 10,
    stats: {
      maxHp: 95,
      speed: 305,
      damage: 15,
      attackRate: 1.55,
      regen: 0.8,
      pickupRange: 150,
    },
  },
  {
    id: "scout",
    name: "游侠",
    description: "高速高攻速，主动技能可以穿梭战场。",
    skillName: "闪避冲刺",
    skillDescription: "E：向面朝方向快速冲刺并短暂无敌。",
    skillCooldown: 5,
    stats: {
      maxHp: 82,
      speed: 395,
      damage: 17,
      attackRate: 2.05,
      critChance: 0.15,
    },
  },
];

export const SHOP_ITEMS = [
  {
    id: "heal",
    name: "战地医疗包",
    description: "花费 8 金币，恢复 35 生命。",
    cost: 8,
    apply: (player) => {
      player.hp = Math.min(player.maxHp, player.hp + 35);
    },
  },
  {
    id: "damage",
    name: "武器校准",
    description: "花费 14 金币，永久伤害 +10%。",
    cost: 14,
    apply: (player) => {
      player.damage *= 1.1;
    },
  },
  {
    id: "armor",
    name: "装甲插片",
    description: "花费 12 金币，护甲 +1。",
    cost: 12,
    apply: (player) => {
      player.armor += 1;
    },
  },
  {
    id: "haste",
    name: "冷却模块",
    description: "花费 16 金币，主动技能冷却 -12%。",
    cost: 16,
    apply: (player) => {
      player.skillCooldownMax *= 0.88;
      player.skillCooldown = Math.min(player.skillCooldown, player.skillCooldownMax);
    },
  },
];

export const UPGRADE_POOL = [
  {
    id: "power",
    name: "力量训练",
    description: "伤害 +25%",
    apply: (player) => {
      player.damage *= 1.25;
    },
  },
  {
    id: "rapid",
    name: "快速装填",
    description: "攻速 +20%",
    apply: (player) => {
      player.attackRate *= 1.2;
    },
  },
  {
    id: "boots",
    name: "轻盈战靴",
    description: "移速 +15%",
    apply: (player) => {
      player.speed *= 1.15;
    },
  },
  {
    id: "vitality",
    name: "生命强化",
    description: "最大生命 +25，并恢复 25",
    apply: (player) => {
      player.maxHp += 25;
      player.hp = Math.min(player.maxHp, player.hp + 25);
    },
  },
  {
    id: "magnet",
    name: "经验磁铁",
    description: "拾取范围 +45%",
    apply: (player) => {
      player.pickupRange *= 1.45;
    },
  },
  {
    id: "multishot",
    name: "多重射击",
    description: "额外发射 1 枚弹丸",
    apply: (player) => {
      player.projectileCount = Math.min(5, player.projectileCount + 1);
    },
  },
  {
    id: "pierce",
    name: "穿透弹头",
    description: "弹丸额外穿透 1 个目标",
    apply: (player) => {
      player.pierce = Math.min(3, player.pierce + 1);
    },
  },
  {
    id: "plating",
    name: "复合护甲",
    description: "护甲 +2",
    apply: (player) => {
      player.armor += 2;
    },
  },
  {
    id: "regeneration",
    name: "自愈因子",
    description: "每秒恢复 1 生命",
    apply: (player) => {
      player.regen += 1;
    },
  },
  {
    id: "precision",
    name: "精准瞄具",
    description: "暴击率 +10%",
    apply: (player) => {
      player.critChance = Math.min(0.6, player.critChance + 0.1);
    },
  },
];

export function getPlayerClass(classId) {
  return PLAYER_CLASSES.find((playerClass) => playerClass.id === classId) ?? PLAYER_CLASSES[0];
}
